const DEFAULT_SITE_LOGO = "israel_tax_authority.png";

// 1. صور البطاقات الأربعة (وصول سريع) حسب اللغة
const QUICK_CARD_IMAGES = {
  ar: [
    "card-1.jpg",
    "card-2.jpg",
    "card-3.jpg",
    "card-4.jpg"
  ],
  he: [
    "imag/img-1.jpg",
    "imag/img-3.jpg",
    "imag/img-5.jpg",
    "imag/img-7.jpg"
  ],
  en: [
    "imag/img-2.jpg",
    "imag/img-4.jpg",
    "imag/img-6.jpg",
    "imag/img-8.jpg"
  ]
};

// 2. صور المعرض المتحرك (Carousel) حسب اللغة
const CAROUSEL_IMAGES = {
  ar: [
    "images/image1.jpg",
    "images/image2.jpg",
    "images/image3.jpg",
    "images/image4.jpg",
    "images/image5.jpg"
  ],
  he: [
    "images/he/image1.jpg",
    "images/he/image2.jpg",
    "images/he/image3.jpg",
    "images/he/image4.jpg",
    "images/he/image5.jpg"
  ],
  en: [
    "images/en/image1.jpg",
    "images/en/image2.jpg",
    "images/en/image3.jpg",
    "images/en/image4.jpg",
    "images/en/image5.jpg"
  ]
};

const translations = {
  ar: {
    lang: "ar",
    dir: "rtl",
    langName: "العربية",
    pageTitle: "سلطة الضرائب — بوابة الخدمات الحكومية",
    menuAria: "فتح القائمة الجانبية",
    brandFallback: "gov.il",
    searchPlaceholder: "ابحث في الخدمات والمعلومات...",
    personalArea: "المنطقة الشخصية",
    navTopics: "المواضيع",
    navServices: "الخدمات",
    navImportant: "معلومات مهمة",
    navAllInfo: "كل المعلومات",
    navUpdates: "آخر المستجدات",
    callCenterText: "مركز الخدمات والاتصال الموحد للاستفسارات والدعم الفني",
    deptFallback: "سلطة<br>الضرائب",
    deptTitle: "سلطة الضرائب",
    moreLinks: "روابط إضافية ▾",
    homeCrumb: "الرئيسية",
    carouselHeading: "أبرز الإعلانات والخدمات",
    slide1Title: "الخدمات الضريبية الإلكترونية",
    slide1Desc: "إدارة الملفات وتقديم الإقرارات عن بُعد بسهولة وأمان.",
    slide2Title: "النماذج والتقارير السنوية",
    slide2Desc: "وصول سريع إلى النماذج المعتمدة ومتابعة حالة الطلبات.",
    slide3Title: "دعم الأفراد وأصحاب الأعمال",
    slide3Desc: "إرشادات واضحة لتنسيق الضرائب وإدارة الحسابات.",
    slide4Title: "التحديثات والأنظمة",
    slide4Desc: "متابعة أحدث التعليمات والقرارات التنظيمية أولاً بأول.",
    slide5Title: "بوابة المدفوعات الآمنة",
    slide5Desc: "تسديد المستحقات والرسوم عبر قنوات دفع إلكترونية موثوقة.",
    resetFilter: "إعادة ضبط",
    newsTag1: "إعلان",
    news1: "تحديث إجراءات الدفع الإلكتروني وتسهيل متابعة الملفات للمكلفين.",
    newsTag2: "تنويه",
    news2: "إتاحة الأدلة الإرشادية المحدثة لتقديم الإقرارات الدورية عبر المنصة.",
    newsTag3: "خدمة",
    news3: "تحسين تجربة حجز المواعيد المسبقة وتقليص فترات الانتظار.",
    quickAccess: "وصول سريع",
    scrollHint: "اسحب أفقياً لاستعراض البطاقات",
    sq1Title: "ضريبة الدخل",
    sq1Sub: "التقارير والملفات",
    sq2Title: "القيمة المضافة",
    sq2Sub: "الفواتير والإقرارات",
    sq3Title: "استرداد الضرائب",
    sq3Sub: "طلبات الفحص والمتابعة",
    sq4Title: "المواعيد والدعم",
    sq4Sub: "مراكز الخدمة والاستفسار",
    imgMissingText: "الصورة غير متوفرة",
    topicsHeading: "المواضيع",
    topic1: "الإقرارات والتقارير الضريبية",
    topic2: "ضريبة القيمة المضافة والجمارك",
    topic3: "الاستردادات والتسويات المالية",
    topic4: "الأعمال والشركات الصغيرة",
    topic5: "التعليمات والقرارات المنظمة",
    moreTopics: "أظهر المزيد المواضيع +",
    lessTopics: "إخفاء المواضيع الإضافية −",
    servicesHeading: "الخدمات",
    badgeOnline: "خدمة إلكترونية",
    cat1Title: "تأمين السلطة للمحتويات المنزلية ضد أضرار الحرب",
    cat1Desc: "يمكن توسيع التغطية التأمينية المقررة بموجب القانون لتشمل...",
    cat2Title: "تقديم مطالبة إلكترونية - ضرر مباشر",
    cat2Desc: "تتيح الخدمة تقديم مطالبة عبر المنصة الإلكترونية في حال...",
    cat3Title: "تنسيق الضرائب إلكترونياً",
    cat3Desc: "تتيح الخدمة للموظفين وأصحاب المشاريع الصغيرة...",
    cat4Title: "طلب استرداد ضريبي - إقرار مختصر",
    cat4Desc: "للأفراد غير الملزمين بتقديم إقرار دخل سنوي كامل...",
    cat5Title: "الدخول إلى المنطقة الشخصية في سلطة الضرائب",
    cat5Desc: "استعراض الإشعارات والوثائق ومتابعة ملفات الضرائب...",
    cat6Title: "حجز موعد في مكاتب سلطة الضرائب",
    cat6Desc: "تحديد موعد مسبق في مراكز استقبال الجمهور لتقليل وقت الانتظار...",
    moreServices: "إظهار خدمات إضافية +",
    lessServices: "إخفاء خدمات إضافية −",
    paymentsBtn: "المدفوعات",
    importantHeading: "معلومات مهمة",
    imp1: "الفرد وصاحب العمل غير الشركة (1301)",
    imp2: "تنسيق الضرائب إلكترونياً",
    imp3: "ترك العمل - إقرار (نموذج 161) رقمي",
    imp4: "دليل الأعمال الجديدة",
    allInfoHeading: "كل المعلومات لك",
    tabPubs: "المنشورات",
    tabPolicy: "السياسات والإجراءات",
    tabGuides: "الأدلة والمزيد",
    pub1Title: "تحديث سقف الدفع ببطاقات الائتمان لسلطة الضرائب",
    pub1Sub: "إلى: المكلفين وأصحاب الأعمال والممثلين.",
    pub1Meta: "النوع: إعلانات عامة • تاريخ النشر: 01.06.2026",
    pub1Updated: "تاريخ التحديث: 02.06.2026",
    pub2Title: "اعتباراً من 1 يونيو 2026: إلزامية التخصيص لخصم ضريبة المدخلات من 5,000 شيكل فأكثر",
    pub2Sub: "تفاصيل التعليمات الجديدة والتطبيق العملي في الفواتير الضريبية.",
    pub2Meta: "النوع: إعلانات عامة • تاريخ النشر: 01.06.2026",
    pol1Title: "إجراءات تقديم الاعتراضات وطلبات التسوية والتقدير",
    pol1Sub: "المواعيد القانونية والمستندات المطلوبة لفحص التقديرات.",
    pol1Meta: "النوع: السياسات والإجراءات • تاريخ التحديث: 15.05.2026",
    guide1Title: "دليل المستخدم للخدمات الرقمية والمنطقة الشخصية",
    guide1Sub: "خطوات بسيطة لإرسال المرفقات ومتابعة الطلبات عبر الإنترنت.",
    guide1Meta: "النوع: الأدلة • تاريخ التحديث: 10.04.2026",
    allPubsLink: "لجميع المنشورات",
    latestLine1: "آخر",
    latestLine2: "التحديثات",
    aboutHeading: "عن السلطة",
    aboutDesc: "توحّد سلطة الضرائب مختلف أقسام الضرائب: ضريبة الدخل، ضريبة العقارات، ضريبة القيمة المضافة، ضريبة الشراء، الجمارك والطوابع. وتقدم السلطة خدمات في مجالات الإصلاحات والجمعيات، إضافة إلى معلومات لأصحاب العمل والممثلين والجمهور.",
    aboutMore: "اقرأ المزيد عن السلطة",
    followUs: "تابعنا:",
    officialsLink: "شاغلو المناصب",
    miniCoord: "تنسيق الضرائب",
    miniForms: "النماذج والإقرارات",
    miniPay: "الدفع الإلكتروني",
    noResults: "لا توجد نتائج مطابقة لبحثك.",
    scrollTop: "↑ للأعلى",
    footerPrefix: "واجهة عرض تجريبية غير رسمية. للخدمات الحكومية الفعلية، تفضل بزيارة ",
    footerLink: "الصفحة الرسمية لسلطة الضرائب",
    chatTitle: "المساعد الذكي لسلطة الضرائب",
    chatWelcome: "مرحباً! أنا المساعد الذكي للعرض التجريبي. كيف يمكنني مساعدتك اليوم في خدمات الضرائب؟",
    chatPlaceholder: "اكتب سؤالك هنا...",
    sendBtn: "إرسال",
    chatReply: "شكراً لتواصلك. يمكنك اختيار موضوع أو الاستعانة بالخدمات السريعة للوصول الفوري.",
    searchResultsPrefix: "نتائج البحث عن"
  },
  en: {
    lang: "en",
    dir: "ltr",
    langName: "English",
    pageTitle: "Tax Authority — Government Services Portal",
    menuAria: "Open navigation menu",
    brandFallback: "gov.il",
    searchPlaceholder: "Search services and information...",
    personalArea: "Personal Area",
    navTopics: "Topics",
    navServices: "Services",
    navImportant: "Important Info",
    navAllInfo: "All Info",
    navUpdates: "Latest Updates",
    callCenterText: "Unified service and support center for inquiries and technical help",
    deptFallback: "Tax<br>Authority",
    deptTitle: "Tax Authority",
    moreLinks: "More links ▾",
    homeCrumb: "Home",
    carouselHeading: "Featured Announcements & Services",
    slide1Title: "Digital Tax Services",
    slide1Desc: "Manage files and submit filings remotely with ease and security.",
    slide2Title: "Forms & Annual Reports",
    slide2Desc: "Quick access to official forms and request tracking.",
    slide3Title: "Individuals & Businesses Support",
    slide3Desc: "Clear guidance for tax coordination and account management.",
    slide4Title: "Updates & Regulations",
    slide4Desc: "Follow the latest directives and regulatory updates.",
    slide5Title: "Secure Payments Gateway",
    slide5Desc: "Pay dues and fees through trusted online channels.",
    resetFilter: "Reset",
    newsTag1: "Notice",
    news1: "Updated online payment procedures and easier file tracking.",
    newsTag2: "Update",
    news2: "Published updated guides for periodic filings online.",
    newsTag3: "Service",
    news3: "Improved appointment booking experience and shorter wait times.",
    quickAccess: "Quick Access",
    scrollHint: "Swipe horizontally to browse cards",
    sq1Title: "Income Tax",
    sq1Sub: "Reports & Files",
    sq2Title: "VAT",
    sq2Sub: "Invoices & Filings",
    sq3Title: "Tax Refunds",
    sq3Sub: "Review & Tracking",
    sq4Title: "Appointments & Support",
    sq4Sub: "Service Centers & Help",
    imgMissingText: "Image unavailable",
    topicsHeading: "Topics",
    topic1: "Tax Filings & Reports",
    topic2: "VAT & Customs",
    topic3: "Refunds & Settlements",
    topic4: "Businesses & Small Enterprises",
    topic5: "Guidelines & Regulations",
    moreTopics: "Show more topics +",
    lessTopics: "Hide extra topics −",
    servicesHeading: "Services",
    badgeOnline: "Online Service",
    cat1Title: "Home Contents War Damage Insurance",
    cat1Desc: "Statutory coverage extension options for citizens...",
    cat2Title: "Online Direct Damage Claim",
    cat2Desc: "Submit a direct damage claim online in case of...",
    cat3Title: "Online Tax Coordination",
    cat3Desc: "Allows salaried employees and small business owners...",
    cat4Title: "Tax Refund Request - Short Report",
    cat4Desc: "Individuals who are not companies and not required to file...",
    cat5Title: "Personal Area Login",
    cat5Desc: "View notices and documents and track tax files...",
    cat6Title: "Book an Appointment",
    cat6Desc: "Schedule ahead at service centers to reduce wait times...",
    moreServices: "Show more services +",
    lessServices: "Hide extra services −",
    paymentsBtn: "Payments",
    importantHeading: "Important Info",
    imp1: "Individual & Non-Company Business (1301)",
    imp2: "Online Tax Coordination",
    imp3: "Leaving Work - Digital Form 161",
    imp4: "Guide for New Businesses",
    allInfoHeading: "All Information For You",
    tabPubs: "Publications",
    tabPolicy: "Policy & Procedures",
    tabGuides: "Guides & More",
    pub1Title: "Credit Card Payment Ceiling Update for the Tax Authority",
    pub1Sub: "To: Taxpayers, businesses, and representatives.",
    pub1Meta: "Type: General Notices • Published: 01.06.2026",
    pub1Updated: "Updated: 02.06.2026",
    pub2Title: "Effective June 1, 2026: Allocation Requirement for Input Tax Deduction from 5,000 NIS",
    pub2Sub: "Details on new guidelines and practical invoice application.",
    pub2Meta: "Type: General Notices • Published: 01.06.2026",
    pol1Title: "Procedures for Objections, Compromises & Assessment Settlements",
    pol1Sub: "Statutory deadlines and required documents for assessment review.",
    pol1Meta: "Type: Policy & Procedures • Updated: 15.05.2026",
    guide1Title: "User Guide for Digital Services & Personal Area",
    guide1Sub: "Simple steps for sending attachments and tracking inquiries online.",
    guide1Meta: "Type: Guides • Updated: 10.04.2026",
    allPubsLink: "All Publications",
    latestLine1: "Latest",
    latestLine2: "Updates",
    aboutHeading: "About the Authority",
    aboutDesc: "The Tax Authority unites tax divisions including income tax, real estate taxation, VAT, purchase tax, customs, and stamp duties, serving taxpayers, employers, representatives, and the public.",
    aboutMore: "Read more about the authority",
    followUs: "Follow us:",
    officialsLink: "Officials",
    miniCoord: "Tax Coordination",
    miniForms: "Forms & Declarations",
    miniPay: "Online Payment",
    noResults: "No matching results found for your search.",
    scrollTop: "↑ Top",
    footerPrefix: "Unofficial demo interface. For official government services, visit ",
    footerLink: "the official Tax Authority page",
    chatTitle: "Tax Authority Smart Assistant",
    chatWelcome: "Hello! I am the demo smart assistant. How can I help you with tax services today?",
    chatPlaceholder: "Type your question here...",
    sendBtn: "Send",
    chatReply: "Thank you for your message. You can choose a topic or use the quick services for fast access.",
    searchResultsPrefix: "Search results for"
  },
  he: {
    lang: "he",
    dir: "rtl",
    langName: "עברית",
    pageTitle: "רשות המסים — פורטל השירותים הממשלתי",
    menuAria: "פתיחת תפריט צד",
    brandFallback: "gov.il",
    searchPlaceholder: "חיפוש שירותים ומידע...",
    personalArea: "אזור אישי",
    navTopics: "נושאים",
    navServices: "שירותים",
    navImportant: "מידע חשוב",
    navAllInfo: "כל המידע",
    navUpdates: "עדכונים אחרונים",
    callCenterText: "מוקד השירות והמידע לפניות ותמיכה",
    deptFallback: "רשות<br>המסים",
    deptTitle: "רשות המסים",
    moreLinks: "קישורים נוספים ▾",
    homeCrumb: "ראשי",
    carouselHeading: "הודעות ושירותים מובילים",
    slide1Title: "שירותי מס דיגיטליים",
    slide1Desc: "ניהול תיקים והגשת דיווחים מרחוק בנוחות ובבטחה.",
    slide2Title: "טפסים ודוחות שנתיים",
    slide2Desc: "גישה מהירה לטפסים רשמיים ומעקב אחר בקשות.",
    slide3Title: "תמיכה ליחידים ולעסקים",
    slide3Desc: "הנחיות ברורות לתיאום מס ולניהול חשבונות.",
    slide4Title: "עדכונים והנחיות",
    slide4Desc: "מעקב אחר הנחיות ועדכונים שוטפים.",
    slide5Title: "שער תשלומים מאובטח",
    slide5Desc: "תשלום חובות ואגרות בערוצים מקוונים מאובטחים.",
    resetFilter: "איפוס",
    newsTag1: "הודעה",
    news1: "עדכון תהליכי תשלום מקוון והנגשת מעקב אחר תיקים.",
    newsTag2: "עדכון",
    news2: "פרסום מדריכים מעודכנים להגשת דוחות תקופתיים.",
    newsTag3: "שירות",
    news3: "שיפור חוויית זימון התורים וקיצור זמני ההמתנה.",
    quickAccess: "גישה מהירה",
    scrollHint: "גללו אופקית לצפייה בכרטיסים",
    sq1Title: "מס הכנסה",
    sq1Sub: "דוחות ותיקים",
    sq2Title: "מע״מ",
    sq2Sub: "חשבוניות ודיווחים",
    sq3Title: "החזרי מס",
    sq3Sub: "בדיקה ומעקב",
    sq4Title: "תורים ותמיכה",
    sq4Sub: "מרכזי שירות ופניות",
    imgMissingText: "התמונה אינה זמינה",
    topicsHeading: "נושאים",
    topic1: "דיווחים ודוחות מס",
    topic2: "מע״מ ומכס",
    topic3: "החזרים והסדרים",
    topic4: "עסקים ועוסקים",
    topic5: "הנחיות ונהלים",
    moreTopics: "הצג נושאים נוספים +",
    lessTopics: "הסתר נושאים נוספים −",
    servicesHeading: "שירותים",
    badgeOnline: "שירות מקוון",
    cat1Title: "ביטוח רשות לתכולה ביתית מנזקי מלחמה",
    cat1Desc: "ניתן להרחיב את הביטוח הניתן על פי חוק לכלל האזרחים...",
    cat2Title: "הגשת תביעה מקוונת - נזק ישיר",
    cat2Desc: "השירות מאפשר להגיש תביעה מקוונת במערכת במקרה של...",
    cat3Title: "תיאום מס מקוון",
    cat3Desc: "השירות מאפשר לשכירים ולבעלי עסקים קטנים...",
    cat4Title: "בקשה להחזר מס - דוח מקוצר למס...",
    cat4Desc: "יחידים שאינם חברה ואינם חייבים בהגשת דוח הכנסה...",
    cat5Title: "כניסה לאזור האישי ברשות המסים",
    cat5Desc: "צפייה בהודעות ומסמכים ומעקב אחר תיקי המס...",
    cat6Title: "זימון תור למשרדי רשות המסים",
    cat6Desc: "קביעת תור מראש במרכזי קבלת הקהל לקיצור זמני ההמתנה...",
    moreServices: "הצג שירותים נוספים +",
    lessServices: "הסתר שירותים נוספים −",
    paymentsBtn: "תשלומים",
    importantHeading: "מידע חשוב",
    imp1: "יחיד ובעל עסק שאינו חברה (1301)",
    imp2: "תיאום מס מקוון",
    imp3: "עזיבת עבודה - דיווח (טופס 161) דיגיטלי",
    imp4: "מדריך לעסקים חדשים",
    allInfoHeading: "כל המידע בשבילכם",
    tabPubs: "פרסומים",
    tabPolicy: "מדיניות ונהלים",
    tabGuides: "מדריכים ו...",
    pub1Title: "עדכון תקרת התשלום בכרטיסי אשראי לרשות המסים בישראל",
    pub1Sub: "אל: ציבור הנישומים, העוסקים והמייצגים.",
    pub1Meta: "סוג: הודעות כלליות • תאריך פרסום: 01.06.2026",
    pub1Updated: "תאריך עדכון: 02.06.2026",
    pub2Title: "החל מ-1 ביוני 2026: חובת הקצאה לניכוי מס תשומות מסכום של 5,000 ₪ ומעלה",
    pub2Sub: "פירוט ההנחיות החדשות והיישום המעשי בחשבוניות מס.",
    pub2Meta: "סוג: הודעות כלליות • תאריך פרסום: 01.06.2026",
    pol1Title: "נהלי הגשת השגות ובקשות לפשרה ויישוב שומות",
    pol1Sub: "מועדים סטטוטוריים ומסמכים נדרשים לבחינת שומות.",
    pol1Meta: "סוג: מדיניות ונהלים • תאריך עדכון: 15.05.2026",
    guide1Title: "מדריך למשתמש בשירותים הדיגיטליים ובאזור האישי",
    guide1Sub: "שלבים פשוטים לשליחת צרופות ומעקב אחר פניות ברשת.",
    guide1Meta: "סוג: מדריכים • תאריך עדכון: 10.04.2026",
    allPubsLink: "לכל הפרסומים",
    latestLine1: "העדכונים",
    latestLine2: "האחרונים",
    aboutHeading: "אודות המשרד",
    aboutDesc: "רשות המסים בישראל מאחדת את אגפי המס השונים: מס הכנסה, מיסוי מקרקעין, מס ערך מוסף, מס קנייה, מכס ובולאות. הרשות מעניקה שירותים בנושאי רפורמות, מלכ״רים וכן מידע למעסיקים, למייצגים ולציבור.",
    aboutMore: "קראו עוד אודות המשרד",
    followUs: "עקבו אחרינו:",
    officialsLink: "נושאי משרה",
    miniCoord: "תיאום מס",
    miniForms: "טפסים והצהרות",
    miniPay: "תשלום מקוון",
    noResults: "לא נמצאו תוצאות התואמות את החיפוש.",
    scrollTop: "↑ למעלה",
    footerPrefix: "ממשק הדגמה לא רשמי. לשירותים ממשלתיים בפועל, בקרו ב",
    footerLink: "העמוד הרשמי של רשות המסים",
    chatTitle: "העוזר החכם של רשות המסים",
    chatWelcome: "שלום! אני העוזר החכם להדגמה. כיצד אוכל לסייע לך היום בשירותי המסים?",
    chatPlaceholder: "כתבו את שאלתכם כאן...",
    sendBtn: "שליחה",
    chatReply: "תודה על פנייתך. ניתן לבחור נושא למטה או להיעזר בשירותים המהירים לגישה מהירה.",
    searchResultsPrefix: "תוצאות חיפוש עבור"
  }
};

// قراءة اللغة المحفوظة من المتصفح عند فتح الصفحة الرئيسية
let currentLang = localStorage.getItem('siteLang') || "ar"; 

let topicsExpanded = false;
let servicesExpanded = false;

// دالة تحديث صور البطاقات الأربعة
function updateQuickAccessCards(lang) {
  const safeLang = QUICK_CARD_IMAGES[lang] ? lang : "ar";
  const dict = translations[safeLang] || translations.ar;
  const images = QUICK_CARD_IMAGES[safeLang];
  const titles = [dict.sq1Title, dict.sq2Title, dict.sq3Title, dict.sq4Title];
  const cards = document.querySelectorAll(".square-links-row .square-link-box");

  cards.forEach((card, index) => {
    const imgPath = images[index];
    if (imgPath) {
      document.documentElement.style.setProperty(`--card-${index + 1}`, `url('${imgPath}')`);
    }
    const labelText = titles[index] || `${safeLang.toUpperCase()} ${index + 1}`;
    card.setAttribute("aria-label", labelText);
  });
}

// دالة تحديث صور المعرض المتحرك (Carousel)
function updateCarouselImages(lang) {
  const safeLang = CAROUSEL_IMAGES[lang] ? lang : "ar";
  const images = CAROUSEL_IMAGES[safeLang];
  const carouselImages = document.querySelectorAll(".carousel-img");

  carouselImages.forEach((imgEl) => {
    const index = parseInt(imgEl.dataset.index, 10);
    if (images[index]) {
      imgEl.src = images[index];
    }
  });
}

function updateMissingImageAlerts() {
  const dict = translations[currentLang] || translations.ar;
  document.querySelectorAll(".img-missing-alert").forEach((alertEl) => {
    alertEl.textContent = dict.imgMissingText;
  });
}

function applySiteLogo(logoUrl = DEFAULT_SITE_LOGO) {
  const slots = document.querySelectorAll(".logo-slot");

  slots.forEach((slot) => {
    let img = slot.querySelector("img");

    if (!img) {
      img = document.createElement("img");
      img.alt = "شعار سلطة الضرائب";
      slot.prepend(img);
    }

    const markLoaded = () => {
      slot.classList.add("has-image");
      slot.querySelector(".img-missing-alert")?.remove();
    };

    const markMissing = () => {
      slot.classList.remove("has-image");
      console.warn("إشعار: تعذّر تحميل الشعار من المسار:", logoUrl);

      const serviceCard = slot.closest(".square-link-box");
      if (serviceCard && !slot.querySelector(".img-missing-alert")) {
        const dict = translations[currentLang] || translations.ar;
        const alertEl = document.createElement("small");
        alertEl.className = "img-missing-alert";
        alertEl.textContent = dict.imgMissingText || "الصورة غير متوفرة";
        slot.appendChild(alertEl);
      }
    };

    img.onload = markLoaded;
    img.onerror = markMissing;
    img.src = logoUrl;

    if (img.complete && img.naturalWidth > 0) {
      markLoaded();
    } else if (img.complete && img.naturalWidth === 0) {
      markMissing();
    }
  });
}

// 2. القائمة الجانبية
const menuButton = document.getElementById("menuButton");
const drawer = document.getElementById("drawer");
const drawerClose = document.getElementById("drawerClose");
const drawerBackdrop = document.getElementById("drawerBackdrop");

function setDrawerOpen(isOpen) {
  drawer.classList.toggle("open", isOpen);
  drawerBackdrop.classList.toggle("open", isOpen);
  drawer.setAttribute("aria-hidden", String(!isOpen));
  menuButton.setAttribute("aria-expanded", String(isOpen));
  if (!isOpen) {
    langDropdownMenu.classList.remove("open");
    langSwitcherBtn.setAttribute("aria-expanded", "false");
  }
}

menuButton.addEventListener("click", () => setDrawerOpen(!drawer.classList.contains("open")));
drawerClose.addEventListener("click", () => setDrawerOpen(false));
drawerBackdrop.addEventListener("click", () => setDrawerOpen(false));

// 2.5 تبديل اللغة (العربية / الإنجليزية / العبرية)
const langSwitcherBtn = document.getElementById("langSwitcherBtn");
const langDropdownMenu = document.getElementById("langDropdownMenu");
const currentLangLabel = document.getElementById("currentLangLabel");
const langOptions = document.querySelectorAll(".lang-option");

function applyLanguage(lang) {
  const dict = translations[lang] || translations.ar;
  currentLang = lang;
  
  // حفظ اللغة في ذاكرة المتصفح لاستخدامها في صفحة login.html
  localStorage.setItem('siteLang', lang);

  document.documentElement.lang = dict.lang;
  document.documentElement.dir = dict.dir;
  document.title = dict.pageTitle;
  currentLangLabel.textContent = dict.langName;

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    if (dict[key] !== undefined) {
      if (key === "brandFallback" || key === "deptFallback") {
        el.innerHTML = dict[key];
      } else {
        el.textContent = dict[key];
      }
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    if (dict[key] !== undefined) {
      el.placeholder = dict[key];
    }
  });

  document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
    const key = el.dataset.i18nAria;
    if (dict[key] !== undefined) {
      el.setAttribute("aria-label", dict[key]);
    }
  });

  // تحديث الصور والبطاقات عند تغيير اللغة
  updateQuickAccessCards(lang);
  updateCarouselImages(lang); // <--- تحديث صور المعرض
  updateMissingImageAlerts();
  
  moreTopicsBtn.textContent = topicsExpanded ? dict.lessTopics : dict.moreTopics;
  moreServicesBtn.textContent = servicesExpanded ? dict.lessServices : dict.moreServices;

  langOptions.forEach((opt) => {
    const isSelected = opt.dataset.lang === lang;
    opt.classList.toggle("active", isSelected);
    opt.setAttribute("aria-selected", String(isSelected));
    const checkSpan = opt.querySelector("span:last-child");
    if (checkSpan) checkSpan.textContent = isSelected ? "✓" : "";
  });

  if (searchInput.value.trim()) {
    filterContent(searchInput.value);
  }
}

langSwitcherBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  const isOpen = langDropdownMenu.classList.toggle("open");
  langSwitcherBtn.setAttribute("aria-expanded", String(isOpen));
});

langOptions.forEach((opt) => {
  opt.addEventListener("click", (e) => {
    e.stopPropagation();
    applyLanguage(opt.dataset.lang);
    langDropdownMenu.classList.remove("open");
    langSwitcherBtn.setAttribute("aria-expanded", "false");
  });
});

// 3. القائمة المنسدلة (روابط إضافية)
const dropdownToggle = document.getElementById("dropdownToggle");
const dropdownMenu = document.getElementById("dropdownMenu");

dropdownToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  const isOpen = dropdownMenu.classList.toggle("open");
  dropdownToggle.setAttribute("aria-expanded", String(isOpen));
});

document.addEventListener("click", () => {
  dropdownMenu.classList.remove("open");
  dropdownToggle.setAttribute("aria-expanded", "false");
  langDropdownMenu.classList.remove("open");
  langSwitcherBtn.setAttribute("aria-expanded", "false");
});

// 4. تحكم معرض الصور الخمس
const photoCarousel = document.getElementById("photoCarousel");
const carouselTrack = document.getElementById("carouselTrack");
const prevPhotoBtn = document.getElementById("prevPhoto");
const nextPhotoBtn = document.getElementById("nextPhoto");
const carouselDots = document.querySelectorAll("#carouselDots button");
const carouselCounter = document.getElementById("carouselCounter");
const totalPhotos = 5;
let currentPhotoIndex = 0;

function updatePhotoCarousel(index) {
  if (index < 0) index = totalPhotos - 1;
  if (index >= totalPhotos) index = 0;
  currentPhotoIndex = index;

  carouselTrack.style.transform = `translateX(-${currentPhotoIndex * 100}%)`;
  carouselCounter.textContent = `${currentPhotoIndex + 1} / ${totalPhotos}`;

  carouselDots.forEach((dot, i) => {
    dot.classList.toggle("active", i === currentPhotoIndex);
  });
}

prevPhotoBtn.addEventListener("click", () => updatePhotoCarousel(currentPhotoIndex - 1));
nextPhotoBtn.addEventListener("click", () => updatePhotoCarousel(currentPhotoIndex + 1));

carouselDots.forEach((dot) => {
  dot.addEventListener("click", () => {
    updatePhotoCarousel(Number(dot.dataset.index));
  });
});

let photoInterval = setInterval(() => {
  updatePhotoCarousel(currentPhotoIndex + 1);
}, 4000);

photoCarousel.addEventListener("mouseenter", () => clearInterval(photoInterval));
photoCarousel.addEventListener("mouseleave", () => {
  photoInterval = setInterval(() => {
    updatePhotoCarousel(currentPhotoIndex + 1);
  }, 4000);
});

let touchStartX = 0;
photoCarousel.addEventListener("touchstart", (e) => {
  touchStartX = e.changedTouches[0].screenX;
  clearInterval(photoInterval);
}, { passive: true });

photoCarousel.addEventListener("touchend", (e) => {
  const touchEndX = e.changedTouches[0].screenX;
  const diff = touchStartX - touchEndX;
  if (Math.abs(diff) > 40) {
    if (diff < 0) {
      updatePhotoCarousel(currentPhotoIndex + 1);
    } else {
      updatePhotoCarousel(currentPhotoIndex - 1);
    }
  }
  photoInterval = setInterval(() => {
    updatePhotoCarousel(currentPhotoIndex + 1);
  }, 4000);
}, { passive: true });

// 5. زر "أظهر المزيد المواضيع +"
const moreTopicsBtn = document.getElementById("moreTopicsBtn");
const extraTopics = document.querySelectorAll(".topic-extra");

moreTopicsBtn.addEventListener("click", () => {
  const dict = translations[currentLang] || translations.ar;
  topicsExpanded = !topicsExpanded;
  extraTopics.forEach((row) => row.classList.toggle("show", topicsExpanded));
  moreTopicsBtn.textContent = topicsExpanded ? dict.lessTopics : dict.moreTopics;
  moreTopicsBtn.setAttribute("aria-expanded", String(topicsExpanded));
});

// 5.5 زر "أظهر المزيد خدمات +"
const moreServicesBtn = document.getElementById("moreServicesBtn");
const extraServices = document.querySelectorAll(".catalog-extra");

moreServicesBtn.addEventListener("click", () => {
  const dict = translations[currentLang] || translations.ar;
  servicesExpanded = !servicesExpanded;
  extraServices.forEach((card) => card.classList.toggle("show", servicesExpanded));
  moreServicesBtn.textContent = servicesExpanded ? dict.lessServices : dict.moreServices;
  moreServicesBtn.setAttribute("aria-expanded", String(servicesExpanded));
});

// 5.8 تبويبات "كل المعلومات من أجلكم"
const infoTabs = document.querySelectorAll(".info-tab-btn");
const infoPanels = document.querySelectorAll(".info-panel");

infoTabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const targetId = `panel-${tab.dataset.tab}`;

    infoTabs.forEach((btn) => {
      const isSelected = btn === tab;
      btn.classList.toggle("active", isSelected);
      btn.setAttribute("aria-selected", String(isSelected));
    });

    infoPanels.forEach((panel) => {
      panel.classList.toggle("active", panel.id === targetId);
    });
  });
});

// 6. زر العودة إلى الأعلى
document.getElementById("scrollTopBtn").addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// 7. نظام البحث الفوري وتصفية المحتوى
const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const searchClear = document.getElementById("searchClear");
const filterStatus = document.getElementById("filterStatus");
const filterText = document.getElementById("filterText");
const filterReset = document.getElementById("filterReset");
const searchableItems = document.querySelectorAll(".searchable-item");
const emptyState = document.getElementById("emptyState");

function filterContent(query) {
  const dict = translations[currentLang] || translations.ar;
  const q = query.trim().toLowerCase();
  searchClear.classList.toggle("visible", q.length > 0);

  if (!q) {
    searchableItems.forEach((item) => item.classList.remove("hidden-item"));
    filterStatus.classList.remove("active");
    emptyState.style.display = "none";
    return;
  }

  let visibleCount = 0;
  searchableItems.forEach((item) => {
    const textToSearch = (item.textContent + " " + (item.querySelector("img")?.alt || "")).toLowerCase();
    const match = textToSearch.includes(q);
    item.classList.toggle("hidden-item", !match);
    if (match) visibleCount++;
  });

  filterStatus.classList.add("active");
  filterText.textContent = `${dict.searchResultsPrefix} "${query}" (${visibleCount})`;
  emptyState.style.display = visibleCount === 0 ? "block" : "none";
}

searchInput.addEventListener("input", (e) => filterContent(e.target.value));
searchForm.addEventListener("submit", (e) => {
  e.preventDefault();
  filterContent(searchInput.value);
  document.getElementById("topics").scrollIntoView({ behavior: "smooth" });
});

function resetSearch() {
  searchInput.value = "";
  filterContent("");
}

searchClear.addEventListener("click", resetSearch);
filterReset.addEventListener("click", resetSearch);
document.getElementById("departmentSearch").addEventListener("click", () => {
  searchInput.focus();
  searchInput.scrollIntoView({ behavior: "smooth", block: "center" });
});

// 8. نافذة المساعد الذكي التفاعلية
const assistantButton = document.getElementById("assistantButton");
const chatModal = document.getElementById("chatModal");
const chatClose = document.getElementById("chatClose");
const chatForm = document.getElementById("chatForm");
const chatInput = document.getElementById("chatInput");
const chatBody = document.getElementById("chatBody");

function setChatOpen(isOpen) {
  chatModal.classList.toggle("open", isOpen);
  chatModal.setAttribute("aria-hidden", String(!isOpen));
  if (isOpen) chatInput.focus();
}

assistantButton.addEventListener("click", () => setChatOpen(true));
chatClose.addEventListener("click", () => setChatOpen(false));
chatModal.addEventListener("click", (e) => {
  if (e.target === chatModal) setChatOpen(false);
});

chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const dict = translations[currentLang] || translations.ar;
  const text = chatInput.value.trim();
  if (!text) return;

  const userMsg = document.createElement("div");
  userMsg.className = "msg user";
  userMsg.textContent = text;
  chatBody.appendChild(userMsg);
  chatInput.value = "";
  chatBody.scrollTop = chatBody.scrollHeight;

  setTimeout(() => {
    const botMsg = document.createElement("div");
    botMsg.className = "msg bot";
    botMsg.textContent = dict.chatReply;
    chatBody.appendChild(botMsg);
    chatBody.scrollTop = chatBody.scrollHeight;
  }, 500);
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    setDrawerOpen(false);
    setChatOpen(false);
    dropdownMenu.classList.remove("open");
    langDropdownMenu.classList.remove("open");
  }
});

// استدعاء الشعار وتطبيق اللغة الافتراضية عند تحميل الصفحة
applySiteLogo(DEFAULT_SITE_LOGO);
applyLanguage(currentLang);